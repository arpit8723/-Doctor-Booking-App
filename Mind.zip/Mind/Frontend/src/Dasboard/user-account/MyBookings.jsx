import React from 'react'

const MyBookings = () => {
  return (
    <div>
      my booking
    </div>
  )
}

export default MyBookings
